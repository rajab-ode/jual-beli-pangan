
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width-device-width, initial-scale=1">
<title> E-COMMERCE </title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body >
	<table width="100%" height="120px">
		<tr>
			<td><img src="toba.png" width="100px" height="120px"></td>
			<td>
				<center>
					<h3> PEMERINTAH KABUPATEN TOBA</h3>
					<h3> DINAS PERTANIAN & PERIKANAN TOBASA </h3>
					<p>Jl. Pertanian No.1, Huta Bulu Mejan, Kec. Balige, Toba, Sumatera Utara 22312</p>
				</center>
			</td>
		</tr>
	</table>
	<!--Header-->
	<header>
		<div class="container">

		<h1><a href="index.php">E-COMMERCE</a></h1>
		<ul>
			<li><a href="homeindex.php">Home</a></li>
			<li><a href="produk.php">Produk</a></li>
			<li><a href="login.php">Login</a></li>
		
	</ul>
	</div>
	</header>
		<div class="gambar">
        <h1><strong><marquee>Selamat Datang, Silahkan Berbelanja!!!</strong></marquee></h1>
        <center>
            <img src="img/img.jpg" alt="" width="90%" height="450px"></center>
	</div>
	<!--Footer-->
	<footer>
	<div class="container">
		<small><h2>Copyright &copy; 2022-Universitas Methodist Indonesia</small></h2>
		</div>
	</footer>
</body>
</html>